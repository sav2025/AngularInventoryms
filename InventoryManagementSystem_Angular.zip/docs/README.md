# InventoryManagementSystem_Angular

Detailed documentation for the project.
